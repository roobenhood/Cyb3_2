    </main>

    <script src="assets/js/main.js?v=<?php echo time(); ?>"></script>
</body>
</html>
