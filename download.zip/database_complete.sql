-- =====================================================
-- AlwaniCTF - Complete Database Schema
-- قاعدة بيانات منصة CTF الكاملة
-- =====================================================
-- تحذير: هذا الملف يحذف جميع الجداول ويعيد إنشاءها من الصفر
-- WARNING: This file drops all tables and recreates them
-- =====================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS cyberctf CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cyberctf;

-- =====================================================
-- حذف الجداول الموجودة (بالترتيب الصحيح للعلاقات)
-- =====================================================
DROP TABLE IF EXISTS `writeup_likes`;
DROP TABLE IF EXISTS `writeups`;
DROP TABLE IF EXISTS `notification_reads`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `otp_codes`;
DROP TABLE IF EXISTS `trusted_devices`;
DROP TABLE IF EXISTS `used_hints`;
DROP TABLE IF EXISTS `submissions`;
DROP TABLE IF EXISTS `solves`;
DROP TABLE IF EXISTS `team_requests`;
DROP TABLE IF EXISTS `challenges`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `activity_log`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `teams`;
DROP TABLE IF EXISTS `settings`;

-- =====================================================
-- 1. جدول الفرق (Teams)
-- =====================================================
CREATE TABLE `teams` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `description` TEXT DEFAULT NULL,
    `captain_id` INT DEFAULT NULL,
    `invite_code` VARCHAR(20) UNIQUE DEFAULT NULL,
    `max_members` INT DEFAULT 5,
    `is_open` TINYINT(1) DEFAULT 1,
    `score` INT DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_score` (`score` DESC),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. جدول المستخدمين (Users)
-- =====================================================
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `email_verified` TINYINT(1) DEFAULT 0,
    `email_verified_at` TIMESTAMP NULL DEFAULT NULL,
    `password` VARCHAR(255) NOT NULL,
    `score` INT DEFAULT 0,
    `team_id` INT DEFAULT NULL,
    `role` ENUM('user', 'admin', 'super_admin') DEFAULT 'user',
    `language` VARCHAR(5) DEFAULT 'ar',
    `avatar` VARCHAR(255) DEFAULT NULL,
    `bio` TEXT DEFAULT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `last_login` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_score` (`score` DESC),
    INDEX `idx_team` (`team_id`),
    INDEX `idx_role` (`role`),
    INDEX `idx_active` (`is_active`),
    FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- تحديث جدول الفرق بعد إنشاء المستخدمين
ALTER TABLE `teams` ADD CONSTRAINT `fk_team_captain` 
    FOREIGN KEY (`captain_id`) REFERENCES `users`(`id`) ON DELETE SET NULL;

-- =====================================================
-- 3. جدول طلبات الانضمام للفرق (Team Requests)
-- =====================================================
CREATE TABLE `team_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `team_id` INT NOT NULL,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_request` (`user_id`, `team_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. جدول الفئات (Categories)
-- =====================================================
CREATE TABLE `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name_en` VARCHAR(50) NOT NULL,
    `name_ar` VARCHAR(50) NOT NULL,
    `description_en` TEXT DEFAULT NULL,
    `description_ar` TEXT DEFAULT NULL,
    `icon` VARCHAR(50) DEFAULT '🏴',
    `color` VARCHAR(20) DEFAULT '#00ff88',
    `sort_order` INT DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. جدول التحديات (Challenges)
-- =====================================================
CREATE TABLE `challenges` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name_en` VARCHAR(100) NOT NULL,
    `name_ar` VARCHAR(100) NOT NULL,
    `description_en` TEXT DEFAULT NULL,
    `description_ar` TEXT DEFAULT NULL,
    `category_id` INT NOT NULL,
    `points` INT NOT NULL DEFAULT 100,
    `difficulty` ENUM('easy', 'medium', 'hard', 'insane') DEFAULT 'medium',
    `flag` VARCHAR(255) NOT NULL,
    `hint_en` TEXT DEFAULT NULL,
    `hint_ar` TEXT DEFAULT NULL,
    `hint_cost` INT DEFAULT 0,
    `folder_name` VARCHAR(100) NOT NULL,
    `max_attempts` INT DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `solves_count` INT DEFAULT 0,
    -- نظام المكافآت
    `bonus_enabled` TINYINT(1) DEFAULT 0,
    `bonus_count` INT DEFAULT 0,
    `bonus_points` TEXT DEFAULT NULL,
    -- نظام النقاط الديناميكي
    `dynamic_scoring` TINYINT(1) DEFAULT 0,
    `initial_points` INT DEFAULT 500,
    `minimum_points` INT DEFAULT 100,
    `decay_rate` DECIMAL(5,2) DEFAULT 50.00,
    -- First Blood Bonus
    `first_blood_bonus` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_category` (`category_id`),
    INDEX `idx_difficulty` (`difficulty`),
    INDEX `idx_active` (`is_active`),
    FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. جدول الحلول (Solves)
-- =====================================================
CREATE TABLE `solves` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `challenge_id` INT NOT NULL,
    `points_earned` INT NOT NULL,
    `is_first_blood` TINYINT(1) DEFAULT 0,
    `solved_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_solve` (`user_id`, `challenge_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_challenge` (`challenge_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `challenges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. جدول المحاولات (Submissions)
-- =====================================================
CREATE TABLE `submissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `challenge_id` INT NOT NULL,
    `submitted_flag` VARCHAR(255) NOT NULL,
    `is_correct` TINYINT(1) DEFAULT 0,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_challenge` (`user_id`, `challenge_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `challenges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. جدول التلميحات المستخدمة (Used Hints)
-- =====================================================
CREATE TABLE `used_hints` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `challenge_id` INT NOT NULL,
    `used_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_hint` (`user_id`, `challenge_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `challenges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. جدول الإشعارات (Notifications)
-- =====================================================
CREATE TABLE `notifications` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title_en` VARCHAR(200) NOT NULL,
    `title_ar` VARCHAR(200) NOT NULL,
    `content_en` TEXT DEFAULT NULL,
    `content_ar` TEXT DEFAULT NULL,
    `type` ENUM('info', 'warning', 'success', 'error') DEFAULT 'info',
    `icon` VARCHAR(50) DEFAULT '📢',
    `target` ENUM('all', 'users', 'teams', 'admins') DEFAULT 'all',
    `is_active` TINYINT(1) DEFAULT 1,
    `created_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_active` (`is_active`),
    INDEX `idx_target` (`target`),
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 10. جدول قراءة الإشعارات (Notification Reads)
-- =====================================================
CREATE TABLE `notification_reads` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `notification_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `read_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_read` (`notification_id`, `user_id`),
    FOREIGN KEY (`notification_id`) REFERENCES `notifications`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 11. جدول Writeups (حلول المستخدمين)
-- =====================================================
CREATE TABLE `writeups` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `challenge_id` INT NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `content` TEXT NOT NULL,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `views_count` INT DEFAULT 0,
    `likes_count` INT DEFAULT 0,
    `approved_by` INT DEFAULT NULL,
    `approved_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_writeup` (`user_id`, `challenge_id`),
    INDEX `idx_status` (`status`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `challenges`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`approved_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 12. جدول إعجابات Writeups
-- =====================================================
CREATE TABLE `writeup_likes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `writeup_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_like` (`writeup_id`, `user_id`),
    FOREIGN KEY (`writeup_id`) REFERENCES `writeups`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 13. جدول رموز OTP
-- =====================================================
CREATE TABLE `otp_codes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `code` VARCHAR(10) NOT NULL,
    `type` ENUM('email_verify', 'login_verify', 'password_reset') NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `is_used` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_type` (`user_id`, `type`),
    INDEX `idx_code` (`code`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 14. جدول الأجهزة الموثوقة (Trusted Devices)
-- =====================================================
CREATE TABLE `trusted_devices` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `device_hash` VARCHAR(64) NOT NULL,
    `device_name` VARCHAR(100) DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `last_used` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_device` (`user_id`, `device_hash`),
    INDEX `idx_user` (`user_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 15. جدول سجل النشاطات (Activity Log)
-- =====================================================
CREATE TABLE `activity_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `severity` ENUM('info', 'warning', 'error', 'critical') DEFAULT 'info',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_severity` (`severity`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 16. جدول الإعدادات (Settings)
-- =====================================================
CREATE TABLE `settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(50) NOT NULL UNIQUE,
    `setting_value` TEXT DEFAULT NULL,
    `description_en` VARCHAR(255) DEFAULT NULL,
    `description_ar` VARCHAR(255) DEFAULT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- إدخال البيانات الافتراضية
-- =====================================================

-- الفئات الافتراضية
INSERT INTO `categories` (`name_en`, `name_ar`, `description_en`, `description_ar`, `icon`, `color`, `sort_order`) VALUES
('Web', 'ويب', 'Web application security challenges', 'تحديات أمان تطبيقات الويب', '🌐', '#3b82f6', 1),
('Cryptography', 'تشفير', 'Encryption and decryption challenges', 'تحديات التشفير وفك التشفير', '🔐', '#8b5cf6', 2),
('Forensics', 'تحليل جنائي', 'Digital forensics and investigation', 'التحليل الجنائي الرقمي والتحقيق', '🔍', '#10b981', 3),
('Reverse Engineering', 'هندسة عكسية', 'Binary analysis and reverse engineering', 'تحليل الملفات والهندسة العكسية', '⚙️', '#f59e0b', 4),
('Pwn', 'استغلال', 'Binary exploitation challenges', 'تحديات استغلال الثغرات', '🐛', '#ef4444', 5),
('OSINT', 'استخبارات', 'Open Source Intelligence', 'الاستخبارات مفتوحة المصدر', '👁️', '#06b6d4', 6),
('Misc', 'متنوع', 'Miscellaneous challenges', 'تحديات متنوعة', '🧩', '#ec4899', 7),
('Steganography', 'إخفاء معلومات', 'Hidden data in media files', 'البيانات المخفية في الملفات', '🖼️', '#84cc16', 8);

-- الإعدادات الافتراضية
INSERT INTO `settings` (`setting_key`, `setting_value`, `description_en`, `description_ar`) VALUES
-- إعدادات عامة
('site_name', 'AlwaniCTF', 'Site name', 'اسم الموقع'),
('site_description', 'Capture The Flag Platform', 'Site description', 'وصف الموقع'),
('default_language', 'ar', 'Default language', 'اللغة الافتراضية'),
('registration_enabled', '1', 'Enable user registration', 'تفعيل التسجيل'),
('team_creation_enabled', '1', 'Enable team creation', 'تفعيل إنشاء الفرق'),
('max_team_members', '5', 'Max team members', 'أقصى عدد للأعضاء'),

-- إعدادات المسابقة
('competition_enabled', '0', 'Enable competition mode', 'تفعيل وضع المسابقة'),
('competition_start', '', 'Competition start time', 'وقت بدء المسابقة'),
('competition_end', '', 'Competition end time', 'وقت انتهاء المسابقة'),
('scoreboard_frozen', '0', 'Freeze scoreboard', 'تجميد لوحة النتائج'),
('scoreboard_frozen_at', '', 'Scoreboard frozen at', 'وقت تجميد لوحة النتائج'),
('scoreboard_freeze_time', '', 'Scoreboard freeze duration', 'مدة التجميد'),

-- إعدادات الأمان والتحقق
('email_verification_required', '0', 'Require email verification', 'تتطلب تحقق البريد'),
('new_device_otp_enabled', '0', 'Enable OTP for new devices', 'تفعيل OTP للأجهزة الجديدة'),
('otp_expiry_minutes', '10', 'OTP expiry in minutes', 'مدة صلاحية OTP بالدقائق'),
('otp_length', '6', 'OTP code length', 'طول رمز OTP'),

-- إعدادات SMTP
('smtp_host', '', 'SMTP server host', 'خادم SMTP'),
('smtp_port', '587', 'SMTP server port', 'منفذ SMTP'),
('smtp_username', '', 'SMTP username', 'اسم مستخدم SMTP'),
('smtp_password', '', 'SMTP password', 'كلمة مرور SMTP'),
('smtp_encryption', 'tls', 'SMTP encryption', 'تشفير SMTP'),
('smtp_from_email', '', 'From email address', 'عنوان البريد المرسل'),
('smtp_from_name', 'AlwaniCTF', 'From name', 'اسم المرسل'),

-- إعدادات Rate Limiting
('login_max_attempts', '5', 'Max login attempts', 'أقصى محاولات تسجيل الدخول'),
('login_lockout_time', '900', 'Lockout time in seconds', 'وقت الإقفال بالثواني'),
('rate_limit_emails', '5', 'Max emails per hour', 'حد الإيميلات بالساعة');

-- =====================================================
-- إنشاء حساب Super Admin
-- =====================================================
INSERT INTO `users` (`username`, `email`, `password`, `role`, `email_verified`, `is_active`, `created_at`)
VALUES ('r3x', 'mrrrr3x@gmail.com', '$2y$10$LLxVr5Y6J8xNE5K7rQpXxOvZ3VqZJZ1qK9mN0hG5dF4cB3aA2zY1W', 'super_admin', 1, 1, NOW());

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- تم الانتهاء من إنشاء قاعدة البيانات
-- Database creation completed
-- =====================================================
