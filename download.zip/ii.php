<?php
// ii.php
// ملف PHP للتشغيل على استضافة خارجية

header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CTF - ii.php</title>
  </head>
  <body>
    <h1>ملف ii.php جاهز</h1>
  </body>
</html>
