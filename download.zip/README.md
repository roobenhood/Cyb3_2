# CyberCTF - منصة مسابقات CTF

منصة كاملة لمسابقات Capture The Flag مكتوبة بـ PHP/MySQL/HTML/CSS/JS

## المتطلبات

- PHP 7.4 أو أحدث
- MySQL 5.7 أو أحدث
- Apache/Nginx مع mod_rewrite

## التثبيت

### 1. إنشاء قاعدة البيانات

```bash
# الدخول إلى MySQL
mysql -u root -p

# إنشاء القاعدة وتنفيذ الملف
source /path/to/php-ctf/database.sql
```

أو من خلال phpMyAdmin:
1. أنشئ قاعدة بيانات باسم `cyberctf`
2. استورد ملف `database.sql`

### 2. تعديل إعدادات الاتصال

عدّل ملف `config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'cyberctf');
define('DB_USER', 'root');        // اسم المستخدم
define('DB_PASS', '');            // كلمة المرور
define('SITE_URL', 'http://localhost/php-ctf');
```

### 3. رفع الملفات

ارفع مجلد `php-ctf` إلى سيرفرك (htdocs أو public_html)

### 4. تأكد من الصلاحيات

```bash
chmod 755 -R php-ctf/
chmod 777 php-ctf/uploads/  # إذا أردت رفع ملفات
```

## بيانات الدخول الافتراضية

**الأدمن:**
- البريد: `admin@cyberctf.com`
- كلمة المرور: `admin123`

⚠️ **مهم:** غيّر كلمة المرور بعد أول دخول!

## الميزات

### للمستخدمين:
- ✅ تسجيل/دخول
- ✅ عرض التحديات وحلها
- ✅ إرسال الفلاجات
- ✅ عرض الترتيب
- ✅ إنشاء/الانضمام للفرق
- ✅ الملف الشخصي

### للأدمن:
- ✅ إدارة التحديات (إضافة/تعديل/حذف)
- ✅ إدارة المستخدمين
- ✅ إدارة الفرق
- ✅ إدارة الفئات
- ✅ إحصائيات شاملة

## هيكل المشروع

```
php-ctf/
├── admin/                  # لوحة التحكم
│   ├── index.php
│   ├── challenges.php
│   ├── users.php
│   ├── teams.php
│   └── categories.php
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── includes/
│   ├── header.php
│   └── footer.php
├── config.php              # إعدادات الموقع
├── database.sql            # هيكل قاعدة البيانات
├── index.php               # الصفحة الرئيسية
├── login.php
├── register.php
├── logout.php
├── challenges.php
├── submit_flag.php
├── scoreboard.php
├── teams.php
├── profile.php
└── README.md
```

## الأمان

- جميع المدخلات تُعقم باستخدام `htmlspecialchars()` و `PDO prepared statements`
- كلمات المرور مشفرة بـ `password_hash()` (bcrypt)
- حماية CSRF يمكن إضافتها
- التحقق من الجلسات في كل صفحة

## إضافة تحدي جديد

1. ادخل للوحة التحكم `/admin/`
2. اذهب إلى "التحديات"
3. اضغط "إضافة تحدي"
4. املأ البيانات:
   - العنوان والوصف
   - الفئة والصعوبة
   - النقاط
   - الفلاج (مثل: `CTF{your_flag_here}`)

## التخصيص

### تغيير الألوان
عدّل المتغيرات في `assets/css/style.css`:

```css
:root {
    --neon-green: #00ff88;
    --neon-cyan: #00d4ff;
    --neon-purple: #a855f7;
    /* ... */
}
```

### إضافة فئة جديدة
من لوحة التحكم أو مباشرة في قاعدة البيانات:

```sql
INSERT INTO categories (name, description, color) 
VALUES ('OSINT', 'Open Source Intelligence', '#00ff88');
```

## المساهمة

المشروع مفتوح المصدر، يمكنك:
- إضافة ميزات جديدة
- إصلاح الأخطاء
- تحسين الأمان
- تحسين التصميم

## الترخيص

MIT License - استخدم المشروع كما تشاء!

---

صُنع بـ ❤️ للمجتمع العربي للأمن السيبراني
