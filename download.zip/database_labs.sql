-- =====================================================
-- AlwaniCTF - Labs Data Insert Only
-- إدراج بيانات اللابات فقط (28 لاب)
-- =====================================================

SET NAMES utf8mb4;
USE cyberctf;

-- =====================================================
-- إضافة فئات اللابات
-- =====================================================
INSERT INTO `categories` (`name_en`, `name_ar`, `description_en`, `description_ar`, `icon`, `color`, `sort_order`, `is_active`) VALUES
('XSS', 'ثغرات XSS', 'Cross-Site Scripting vulnerability labs', 'معامل ثغرات البرمجة النصية عبر المواقع', '💉', '#f97316', 10, 1),
('SQL Injection', 'حقن SQL', 'SQL Injection vulnerability labs', 'معامل ثغرات حقن قواعد البيانات', '🗃️', '#dc2626', 11, 1),
('File Upload', 'رفع الملفات', 'File Upload vulnerability labs', 'معامل ثغرات رفع الملفات', '📁', '#16a34a', 12, 1),
('Path Traversal', 'اجتياز المسار', 'Path Traversal vulnerability labs', 'معامل ثغرات اجتياز المسار', '📂', '#9333ea', 13, 1);

-- =====================================================
-- XSS Labs (7 تحديات)
-- =====================================================
INSERT INTO `challenges` (`name_en`, `name_ar`, `description_en`, `description_ar`, `category_id`, `points`, `difficulty`, `flag`, `hint_en`, `hint_ar`, `hint_cost`, `folder_name`, `max_attempts`, `is_active`, `bonus_enabled`, `dynamic_scoring`, `first_blood_bonus`) VALUES
('Reflected XSS - Basic Search', 'XSS المنعكس - البحث الأساسي', 'A simple search functionality that reflects user input. Find a way to execute JavaScript in the page.', 'وظيفة بحث بسيطة تعكس مدخلات المستخدم. جد طريقة لتنفيذ JavaScript في الصفحة.', (SELECT id FROM categories WHERE name_en = 'XSS'), 100, 'easy', 'FLAG{REFLECTED_XSS_BASIC_COMPLETED}', 'Try injecting script tags in the search parameter', 'جرب حقن وسوم script في معامل البحث', 25, 'xss/beginner/lab1_reflected', 0, 1, 1, 0, 50),

('Stored XSS - Forum Comments', 'XSS المخزن - تعليقات المنتدى', 'A forum where users can post comments. Your malicious payload will be stored and executed when others view it.', 'منتدى حيث يمكن للمستخدمين نشر التعليقات. سيتم تخزين الحمولة الخبيثة وتنفيذها عند مشاهدة الآخرين لها.', (SELECT id FROM categories WHERE name_en = 'XSS'), 150, 'easy', 'FLAG{STORED_XSS_FORUM_PWNED}', 'Post a comment with embedded JavaScript', 'انشر تعليقاً يحتوي على JavaScript مضمن', 30, 'xss/beginner/lab2_stored', 0, 1, 1, 0, 50),

('DOM XSS - URL Hash', 'XSS DOM - هاش الرابط', 'The page reads from the URL hash and inserts it into the DOM. Exploit this client-side vulnerability.', 'تقرأ الصفحة من هاش الرابط وتدرجه في DOM. استغل هذه الثغرة من جانب العميل.', (SELECT id FROM categories WHERE name_en = 'XSS'), 200, 'medium', 'FLAG{DOM_XSS_HASH_EXPLOITED}', 'Check the JavaScript code that handles the URL hash', 'تحقق من كود JavaScript الذي يتعامل مع هاش الرابط', 40, 'xss/intermediate/lab3_dom', 0, 1, 1, 0, 75),

('XSS Filter Bypass', 'تجاوز فلتر XSS', 'The application has a basic XSS filter. Find a way to bypass it and execute JavaScript.', 'يحتوي التطبيق على فلتر XSS أساسي. جد طريقة لتجاوزه وتنفيذ JavaScript.', (SELECT id FROM categories WHERE name_en = 'XSS'), 250, 'medium', 'FLAG{XSS_FILTER_BYPASSED}', 'Try using different HTML tags or event handlers', 'جرب استخدام وسوم HTML مختلفة أو معالجات الأحداث', 50, 'xss/intermediate/lab4_filter', 0, 1, 1, 0, 75),

('XSS Cookie Stealer', 'XSS لسرقة الكوكيز', 'Steal the admin cookie using XSS. The admin bot will visit the page with the vulnerable comment.', 'اسرق كوكيز المدير باستخدام XSS. سيزور بوت المدير الصفحة التي تحتوي على التعليق المصاب.', (SELECT id FROM categories WHERE name_en = 'XSS'), 300, 'medium', 'FLAG{COOKIE_STOLEN_SUCCESS}', 'Use document.cookie and send it to an external server', 'استخدم document.cookie وأرسله لخادم خارجي', 60, 'xss/intermediate/lab5_cookie', 0, 1, 1, 0, 100),

('XSS CSP Bypass', 'تجاوز CSP مع XSS', 'The page has Content Security Policy. Find a misconfiguration to bypass it and execute XSS.', 'تحتوي الصفحة على سياسة أمان المحتوى. جد خطأ في التكوين لتجاوزها وتنفيذ XSS.', (SELECT id FROM categories WHERE name_en = 'XSS'), 400, 'hard', 'FLAG{CSP_BYPASSED_XSS_WIN}', 'Check the CSP header for allowed sources', 'تحقق من ترويسة CSP للمصادر المسموح بها', 80, 'xss/advanced/lab6_csp', 0, 1, 1, 1, 150),

('Real World XSS - Banking App', 'XSS واقعي - تطبيق بنكي', 'A realistic banking application with multiple XSS vectors. Find and exploit them to steal user data.', 'تطبيق بنكي واقعي مع عدة نقاط XSS. اكتشفها واستغلها لسرقة بيانات المستخدم.', (SELECT id FROM categories WHERE name_en = 'XSS'), 500, 'hard', 'FLAG{REAL_WORLD_XSS_MASTER}', 'Check all user inputs: support chat, profile, transfers', 'تحقق من جميع مدخلات المستخدم: دعم الدردشة، الملف الشخصي، التحويلات', 100, 'xss/advanced/lab7_real', 0, 1, 1, 1, 200);

-- =====================================================
-- SQL Injection Labs (7 تحديات)
-- =====================================================
INSERT INTO `challenges` (`name_en`, `name_ar`, `description_en`, `description_ar`, `category_id`, `points`, `difficulty`, `flag`, `hint_en`, `hint_ar`, `hint_cost`, `folder_name`, `max_attempts`, `is_active`, `bonus_enabled`, `dynamic_scoring`, `first_blood_bonus`) VALUES
('SQLi Login Bypass', 'تجاوز تسجيل الدخول بـ SQLi', 'Bypass the login form using SQL injection to access the admin panel.', 'تجاوز نموذج تسجيل الدخول باستخدام حقن SQL للوصول إلى لوحة المدير.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 100, 'easy', 'FLAG{SQL_LOGIN_BYPASSED}', 'Try classic SQL injection: OR 1=1', 'جرب حقن SQL الكلاسيكي: OR 1=1', 25, 'sqli/beginner/lab1_login_bypass', 0, 1, 1, 0, 50),

('UNION Based SQLi', 'حقن UNION SQL', 'Extract data from other tables using UNION-based SQL injection.', 'استخرج البيانات من جداول أخرى باستخدام حقن UNION SQL.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 150, 'easy', 'FLAG{UNION_SQLI_DATA_EXTRACTED}', 'First find the number of columns, then use UNION SELECT', 'أولاً اكتشف عدد الأعمدة، ثم استخدم UNION SELECT', 30, 'sqli/beginner/lab2_union', 0, 1, 1, 0, 50),

('Blind SQLi - Boolean Based', 'حقن SQL الأعمى - Boolean', 'Extract data using boolean-based blind SQL injection. No direct output is shown.', 'استخرج البيانات باستخدام حقن SQL الأعمى المبني على Boolean. لا يظهر أي مخرجات مباشرة.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 250, 'medium', 'FLAG{BLIND_SQLI_BOOLEAN_WIN}', 'Use IF conditions and observe response differences', 'استخدم شروط IF ولاحظ الفروقات في الاستجابة', 50, 'sqli/intermediate/lab3_blind', 0, 1, 1, 0, 75),

('Error Based SQLi', 'حقن SQL المبني على الأخطاء', 'Extract data through database error messages.', 'استخرج البيانات من خلال رسائل أخطاء قاعدة البيانات.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 200, 'medium', 'FLAG{ERROR_BASED_SQLI_DONE}', 'Use EXTRACTVALUE or UPDATEXML functions to trigger errors', 'استخدم دوال EXTRACTVALUE أو UPDATEXML لإثارة الأخطاء', 40, 'sqli/intermediate/lab4_error', 0, 1, 1, 0, 75),

('Stacked Queries SQLi', 'حقن SQL متعدد الاستعلامات', 'Execute multiple SQL statements to modify data in the database.', 'نفذ عدة استعلامات SQL لتعديل البيانات في قاعدة البيانات.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 300, 'medium', 'FLAG{STACKED_QUERIES_EXECUTED}', 'Use semicolon to separate queries', 'استخدم الفاصلة المنقوطة لفصل الاستعلامات', 60, 'sqli/intermediate/lab5_stacked', 0, 1, 1, 0, 100),

('SQLi WAF Bypass', 'تجاوز جدار الحماية مع SQLi', 'The application has a Web Application Firewall. Bypass it to perform SQL injection.', 'يحتوي التطبيق على جدار حماية للويب. تجاوزه لتنفيذ حقن SQL.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 400, 'hard', 'FLAG{WAF_BYPASSED_SQLI}', 'Try encoding, comments, or case manipulation', 'جرب الترميز، التعليقات، أو تغيير حالة الأحرف', 80, 'sqli/advanced/lab6_waf', 0, 1, 1, 1, 150),

('Real World SQLi - Bank Transfer', 'SQLi واقعي - تحويل بنكي', 'A realistic banking application. Exploit SQL injection to transfer money to your account.', 'تطبيق بنكي واقعي. استغل حقن SQL لتحويل الأموال إلى حسابك.', (SELECT id FROM categories WHERE name_en = 'SQL Injection'), 500, 'hard', 'FLAG{REAL_WORLD_SQLI_BANK_PWNED}', 'Check the transfer functionality for injection points', 'تحقق من وظيفة التحويل لنقاط الحقن', 100, 'sqli/advanced/lab7_real', 0, 1, 1, 1, 200);

-- =====================================================
-- File Upload Labs (7 تحديات)
-- =====================================================
INSERT INTO `challenges` (`name_en`, `name_ar`, `description_en`, `description_ar`, `category_id`, `points`, `difficulty`, `flag`, `hint_en`, `hint_ar`, `hint_cost`, `folder_name`, `max_attempts`, `is_active`, `bonus_enabled`, `dynamic_scoring`, `first_blood_bonus`) VALUES
('Basic File Upload', 'رفع ملفات أساسي', 'The application has no restrictions on file upload. Upload a malicious file to get code execution.', 'التطبيق ليس لديه قيود على رفع الملفات. ارفع ملفاً خبيثاً للحصول على تنفيذ الكود.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 100, 'easy', 'FLAG{BASIC_UPLOAD_RCE}', 'Try uploading a PHP file directly', 'جرب رفع ملف PHP مباشرة', 25, 'fileupload/beginner/lab1_basic', 0, 1, 1, 0, 50),

('MIME Type Bypass', 'تجاوز نوع MIME', 'The application only checks MIME type. Bypass this restriction to upload PHP.', 'يتحقق التطبيق من نوع MIME فقط. تجاوز هذا القيد لرفع PHP.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 150, 'easy', 'FLAG{MIME_TYPE_BYPASSED}', 'Change the Content-Type header when uploading', 'غير ترويسة Content-Type عند الرفع', 30, 'fileupload/beginner/lab2_mimetype', 0, 1, 1, 0, 50),

('Content Validation Bypass', 'تجاوز التحقق من المحتوى', 'The application validates file content. Find a way to bypass this check.', 'يتحقق التطبيق من محتوى الملف. جد طريقة لتجاوز هذا الفحص.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 200, 'medium', 'FLAG{CONTENT_CHECK_BYPASSED}', 'Add valid image headers (magic bytes) to your PHP file', 'أضف ترويسات صور صالحة (magic bytes) لملف PHP', 40, 'fileupload/intermediate/lab3_content', 0, 1, 1, 0, 75),

('Null Byte Injection', 'حقن البايت الفارغ', 'The application appends an extension. Use null byte to bypass this.', 'يضيف التطبيق امتداداً. استخدم البايت الفارغ لتجاوز هذا.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 250, 'medium', 'FLAG{NULL_BYTE_INJECTION_WIN}', 'Try shell.php%00.jpg', 'جرب shell.php%00.jpg', 50, 'fileupload/intermediate/lab4_nullbyte', 0, 1, 1, 0, 75),

('Race Condition Upload', 'رفع ملفات بظروف السباق', 'The application deletes malicious files quickly. Exploit the race condition to execute before deletion.', 'يحذف التطبيق الملفات الخبيثة بسرعة. استغل ظروف السباق للتنفيذ قبل الحذف.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 300, 'medium', 'FLAG{RACE_CONDITION_EXPLOITED}', 'Send multiple requests simultaneously', 'أرسل عدة طلبات في وقت واحد', 60, 'fileupload/intermediate/lab5_race', 0, 1, 1, 0, 100),

('ZIP Symlink Attack', 'هجوم الروابط الرمزية ZIP', 'The application extracts ZIP files. Use symlinks to read sensitive files.', 'يقوم التطبيق باستخراج ملفات ZIP. استخدم الروابط الرمزية لقراءة الملفات الحساسة.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 400, 'hard', 'FLAG{ZIP_SYMLINK_FILE_READ}', 'Create a ZIP with a symlink pointing to /etc/passwd or flag file', 'أنشئ ZIP يحتوي على رابط رمزي يشير إلى /etc/passwd أو ملف العلم', 80, 'fileupload/advanced/lab6_zip', 0, 1, 1, 1, 150),

('Real World File Upload - Image Editor', 'رفع ملفات واقعي - محرر صور', 'A realistic image editing application with multiple security layers. Bypass them all.', 'تطبيق تحرير صور واقعي مع طبقات أمان متعددة. تجاوزها جميعاً.', (SELECT id FROM categories WHERE name_en = 'File Upload'), 500, 'hard', 'FLAG{REAL_WORLD_UPLOAD_MASTER}', 'Combine multiple bypass techniques: extension, content, and processing', 'اجمع عدة تقنيات تجاوز: الامتداد، المحتوى، والمعالجة', 100, 'fileupload/advanced/lab7_real', 0, 1, 1, 1, 200);

-- =====================================================
-- Path Traversal Labs (7 تحديات)
-- =====================================================
INSERT INTO `challenges` (`name_en`, `name_ar`, `description_en`, `description_ar`, `category_id`, `points`, `difficulty`, `flag`, `hint_en`, `hint_ar`, `hint_cost`, `folder_name`, `max_attempts`, `is_active`, `bonus_enabled`, `dynamic_scoring`, `first_blood_bonus`) VALUES
('Basic Path Traversal', 'اجتياز المسار الأساسي', 'The application reads files based on user input. Traverse to read sensitive files.', 'يقرأ التطبيق الملفات بناءً على مدخلات المستخدم. اجتز المسار لقراءة الملفات الحساسة.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 100, 'easy', 'FLAG{BASIC_PATH_TRAVERSAL_WIN}', 'Try using ../ to go up directories', 'جرب استخدام ../ للصعود في المجلدات', 25, 'path_traversal/beginner/lab1_basic', 0, 1, 1, 0, 50),

('URL Encoded Traversal', 'اجتياز المسار بالترميز', 'The application blocks ../ directly. Bypass using URL encoding.', 'يحظر التطبيق ../ مباشرة. تجاوز باستخدام ترميز URL.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 150, 'easy', 'FLAG{URL_ENCODED_TRAVERSAL}', 'Try %2e%2e%2f or double encoding', 'جرب %2e%2e%2f أو الترميز المزدوج', 30, 'path_traversal/beginner/lab2_encoded', 0, 1, 1, 0, 50),

('Nested Traversal Bypass', 'تجاوز الاجتياز المتداخل', 'The application removes ../ once. Use nested sequences to bypass.', 'يزيل التطبيق ../ مرة واحدة. استخدم تسلسلات متداخلة للتجاوز.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 200, 'medium', 'FLAG{NESTED_TRAVERSAL_BYPASSED}', 'Try ....// or ..././ patterns', 'جرب أنماط ....// أو ..././', 40, 'path_traversal/intermediate/lab3_nested', 0, 1, 1, 0, 75),

('Double URL Encoding', 'الترميز المزدوج للـ URL', 'The application URL-decodes then filters. Use double encoding to bypass.', 'يفك التطبيق ترميز URL ثم يفلتر. استخدم الترميز المزدوج للتجاوز.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 250, 'medium', 'FLAG{DOUBLE_ENCODED_PATH}', 'Encode the % sign itself: %252e%252e%252f', 'رمز علامة % نفسها: %252e%252e%252f', 50, 'path_traversal/intermediate/lab4_double', 0, 1, 1, 0, 75),

('Path Truncation', 'اقتطاع المسار', 'The application validates path length. Use truncation techniques to bypass.', 'يتحقق التطبيق من طول المسار. استخدم تقنيات الاقتطاع للتجاوز.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 300, 'medium', 'FLAG{PATH_TRUNCATION_EXPLOIT}', 'Try very long paths or null bytes', 'جرب مسارات طويلة جداً أو بايتات فارغة', 60, 'path_traversal/intermediate/lab5_truncate', 0, 1, 1, 0, 100),

('Absolute Path Injection', 'حقن المسار المطلق', 'The application prepends a base directory. Use absolute path to bypass.', 'يضيف التطبيق مجلداً أساسياً. استخدم المسار المطلق للتجاوز.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 400, 'hard', 'FLAG{ABSOLUTE_PATH_BYPASSED}', 'Try starting with / to ignore the base path', 'جرب البدء بـ / لتجاهل المسار الأساسي', 80, 'path_traversal/advanced/lab6_absolute', 0, 1, 1, 1, 150),

('Real World Path Traversal - File Manager', 'اجتياز المسار الواقعي - مدير الملفات', 'A realistic file manager application. Find and exploit path traversal to access system files.', 'تطبيق مدير ملفات واقعي. اكتشف واستغل اجتياز المسار للوصول لملفات النظام.', (SELECT id FROM categories WHERE name_en = 'Path Traversal'), 500, 'hard', 'FLAG{REAL_WORLD_PATH_MASTER}', 'Check file download, preview, and backup features', 'تحقق من ميزات تحميل الملفات، المعاينة، والنسخ الاحتياطي', 100, 'path_traversal/advanced/lab7_real', 0, 1, 1, 1, 200);

-- =====================================================
-- ملخص الإدراج
-- =====================================================
-- XSS: 7 labs (1900 points)
-- SQLi: 7 labs (1900 points)
-- File Upload: 7 labs (1900 points)
-- Path Traversal: 7 labs (1900 points)
-- المجموع: 28 lab, 7600 points
-- =====================================================
